#include <stdio.h>
#include <sys/reg.h>
#include <sys/ptrace.h>
#include <sys/ldr.h>
#include <sys/wait.h>
#include<sys/errno.h>
#include<sys/signal.h>

int main(void)
{
	int wait_val,i; 
	int pid,counter=0; 
	int BPT=0x7D821008;
	int *addr = (int *)0x10000340; 
	int inst;
	int buf1[1024];

        printf("Enter the pid \n");
	scanf("%d",&pid);
	printf("pid=%d\n\n",pid);
	fflush(stdout);

	if(ptrace(PT_ATTACH, pid, 0, 0, 0)!=0)
		perror("PT_ATTACH");
	waitpid(pid,&wait_val,0);
	if(WIFSTOPPED(wait_val))
		printf("Attached \n");
	else
		printf("Some error\n");

	if ((inst=ptrace(PT_READ_BLOCK, pid, addr, 48, buf1)) != 48)
	{
		perror("unable to read inst at abc ");
		printf("errno=%d\n",inst);
	}
	printf("read value %X \n",*((int *)buf1));

/*	if ((i=ptrace(PT_WRITE_BLOCK, pid, addr, 48, buf2)) != 48)
	{
		perror("unable to write inst at abc \n");
		printf("%d i=%d\n",errno,i);
	}*/

/*
	if(ptrace(PT_CONTINUE,pid,(int *)1,0,0) == -1)
	{
		perror("unable to continue -madhu\n");
	}
*/

	scanf("%d",&inst);

	printf("Detaching .... %d\n",pid);
        if(ptrace(PT_DETACH, pid, 0, SIGPWR, 0) == -1)
	{
		perror("Detach didn't happen\n");
	}
	perror("hi");

	printf("Done]\n");
        return 0;
}

