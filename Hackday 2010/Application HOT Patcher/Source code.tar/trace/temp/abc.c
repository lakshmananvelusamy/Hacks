#include<stdio.h>


myfunc()
{
	printf("dynamic fix.....Wow.....e!\n");
	fflush(stdout);
}
