#include<stdio.h>


main()
{
	int (*fp)();
	int h=dlopen("./shr.o",2);
	fp=dlsym(h,"myfunc");
	(*fp)();
}
