#include<stdio.h>

myfunc()
{	int i;
	printf("my func\n");
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	
}

main()
{
	while(1)
	{
	myfunc();
	sleep(5);
	}
}
