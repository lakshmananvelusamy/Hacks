pid=$1
oldfp=$2

echo Hello $pid $oldfp 

echo "p &$oldfp" >source
echo "detach" >>source

dbx -a $1 -c source $2 >result

oldfp=`tail -1 result | head -1`

echo oldfp=$oldfp

./a.out $1 $oldfp $3 $4 $5

