#include <stdio.h>
#include <sys/reg.h>
#include <sys/ptrace.h>
#include <sys/ldr.h>
#include <sys/wait.h>
#include<sys/errno.h>
#include<sys/signal.h>
#include "patch.h"

int 
getbranchcode(int *opcodes,int *address)
{
	unsigned int i,addr=(unsigned int) address;
	unsigned int buf[256]={	0X38600000, /*  li r3, 0 */
			0X64630000, /*    oris   r3,r3,0x0000 Upper */
			0X60630000, /*    ori   r3,r3,0x0000 Lower */ 
			0X7c6903a6, /*        mtctr   r3 */
			0X4e800420 /*        bctr */ };

	buf[1]|= (addr & 0XFFFF0000)>>16;
	buf[2]|= (addr & 0X0000FFFF);
	memcpy(opcodes,buf,20);
}

int pattach(pid_t pid)
{
	int wait_val;
	if(ptrace(PT_ATTACH, pid, 0, 0, 0)!=0)
	{
		perror("PT_ATTACH");
		return -1;
	}
	waitpid(pid,&wait_val,0);
	if(WIFSTOPPED(wait_val))
		printf("Attached\n");
	else
	{
		printf("It is not attached..\n");
		return -1;
	}
	return 0;
}
int pread(pid_t pid,int *addr, int *buf,int siz)
{
	int i;
	if ((i=ptrace(PT_READ_BLOCK, pid, addr, siz, buf)) != siz)
	{
		perror("unable to read inst at abc ");
		printf("errno=%d\n",i);
		return -1;
	}
	return 0;
}

int pwrite(pid_t pid,int *addr, int *buf,int siz)
{
	int i;

	if ((i=ptrace(PT_WRITE_BLOCK, pid, addr, siz, buf)) != siz)
	{
		perror("unable to write inst at abc \n");
		printf("%d i=%d\n",errno,i);
		return -1;
	}
	return 0;
}

int pdetach(pid_t pid)
{
        if(ptrace(PT_DETACH, pid, 0, SIGPWR, 0) == -1)
	{
		perror("Detach didn't happen\n");
		return -1;
	}
	printf("Detached\n");
	return 0;
}

int patch(pid_t pid,int *oldfp, int *newfp)
{
	int rbuf[256],wbuf[256];
	pattach(pid);
	pread(pid,oldfp,rbuf,20);
	getbranchcode(wbuf,newfp);
	pwrite(pid,oldfp,wbuf,20);
	pdetach(pid);
}

#define BPT 0x10000340

int main(void)
{
	int wait_val,i; 
	int pid,counter=0; 
	int *oldfp = (int *)0x10000340; 
	int *newfp = (int *)0x10000460; 
	int inst;
	int buf1[1024]={0},buf2[1024];

        printf("Enter the pid \n");
	scanf("%d",&pid);
	printf("pid=%d\n\n",pid);
	fflush(stdout);

	patch(pid,oldfp,newfp);

        return 0;
}

