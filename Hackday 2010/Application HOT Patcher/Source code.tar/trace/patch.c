#include<stdio.h>

int patch_function()
{
	printf("Inside the patch function .......\n");
	return 0;
}
