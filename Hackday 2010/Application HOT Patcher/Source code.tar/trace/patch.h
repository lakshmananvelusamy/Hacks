#include <stdio.h>
#include <sys/reg.h>
#include <sys/ptrace.h>
#include <sys/ldr.h>
#include <sys/wait.h>
#include<sys/errno.h>
#include<sys/signal.h>

#define BPT 0x10000340

int
loadr4(unsigned int *opcodes, unsigned int value)
{
	opcodes[0]=0X38800000;    				/*      li   r4,0x0	    */
	opcodes[1]=0X64840000 | ((value & 0XFFFF0000) >> 16);    /*    oris   r4,r4,0xf066    */
	opcodes[2]=0X60840000 | (value & 0X0000FFFF);    	/*     ori   r4,r4,0x6870    */
	opcodes[3]=0X60000000;
	return 16;
}
int
loadr41(unsigned int *opcodes, unsigned int value)
{
	opcodes[0]=0X7c651b78;    				/*      li   r4,0x0	    */
	opcodes[1]=0X38600000;    				/*      li   r3,0x0	    */
	opcodes[2]=0X64630000 | ((value & 0XFFFF0000) >> 16);    /*    oris   r3,r3,0xf066    */
	opcodes[3]=0X60630000 | (value & 0X0000FFFF);    	/*     ori   r3,r3,0x6870    */
	opcodes[4]=0X7c641b78;
	opcodes[5]=0X7ca32b78;
	return 24;
}


int
loadr3(unsigned int *opcodes, unsigned int value)
{
	opcodes[0]=0X38600000;    				/*      li   r3,0x0	    */
	opcodes[1]=0X64630000 | ((value & 0XFFFF0000) >> 16);    /*    oris   r3,r3,0xf066    */
	opcodes[2]=0X60630000 | (value & 0X0000FFFF);    	/*     ori   r3,r3,0x6870    */
	return 12;
}

int
loadprolog(unsigned int *opcodes)
{
	opcodes[0] = 0x7c0802a6;	/*        mflr   r0 	*/
	opcodes[1] = 0x90010008;	/*        stw   r0,0x8(r1)  */
	opcodes[2] = 0x9421ffc0;	/*        stwu   r1,-64(r1) */
	return 12;
}

int
loadepilog(int *opcodes)
{
	opcodes[0] = 0x38210040;	/*        addi   r1,0x40(r1)            */
	opcodes[1] = 0x80010008;	/*         lwz   r0,0x8(r1)             */
	opcodes[2] = 0x7c0803a6;	/*        mtlr   r0                     */
	opcodes[3] = 0x4e800021;	/*       blrl                           */
	return 16;
}

int 
loadcall(int *opcodes, int *tocaddr,int dbg)
{
	unsigned int i,toc=(unsigned int) tocaddr;
	
	opcodes[0] = 0x39800000;  				/*       li   r12,0x0                        */
	opcodes[1] = 0x658c0000 | ((toc & 0XFFFF0000)>>16); 	/*       oris   r12,r12,0xf066 Upper         */
	opcodes[2] = 0x618c0000 | (toc & 0X0000FFFF);		/*       ori   r12,r12,0x6870 LOWER          */
	opcodes[3] = 0x90410014;  				/*       stw   r2,0x14(r1)		     */
	opcodes[4] = 0x800c0000;  				/*       lwz   r0,0x0(r12)		     */
	opcodes[5] = 0x804c0004;  				/*       lwz   r2,0x4(r12)		     */
	opcodes[6] = 0x7c0903a6; 				/*       mtctr   r0			     */
	if(dbg)
		opcodes[7] = BPT;  				/*       mtctr   r0			     */
	else
	opcodes[7] = 0x4e800421;  				/*       bctrl				     */
	opcodes[8] = 0x60000000;  				/*       ori   r0,r0,0x0		     */
	opcodes[9] = 0x80410014; 				/*       lwz   r2,0x14(r1)		     */

	return 40;
}

int 
loadjump(int *opcodes,int *address)
{
	unsigned int i,addr=(unsigned int) address;
	unsigned int buf[256]={	0X38600000, /*  li r3, 0 */
			0X64630000, /*    oris   r3,r3,0x0000 Upper */
			0X60630000, /*    ori   r3,r3,0x0000 Lower */ 
			0X7c6903a6, /*        mtctr   r3 */
			0X4e800420 /*        bctr */ };

	buf[1]|= (addr & 0XFFFF0000)>>16;
	buf[2]|= (addr & 0X0000FFFF);
	memcpy(opcodes,buf,20);
	return 20;
}

int pattach(pid_t pid)
{
	int wait_val;
	if(ptrace(PT_ATTACH, pid, 0, 0, 0)!=0)
	{
		perror("PT_ATTACH");
		return -1;
	}
	waitpid(pid,&wait_val,0);
	if(WIFSTOPPED(wait_val))
		printf("Attached\n");
	else
	{
		printf("It is not attached..\n");
		return -1;
	}
	return 0;
}
int pcontinue(pid_t pid)
{
	int wait_val;
        if(ptrace(PT_CONTINUE,pid,(int *)1,0,0) == -1)
        {
                perror("unable to continue -madhu\n");
        }
	waitpid(pid,&wait_val,0);

	
}

int preadreg(pid_t pid,int reg)
{
	int i;
	if ((i=ptrace(PT_READ_GPR, pid, (int *)reg, NULL, NULL)) == -1)
	{
		perror("unable to read reg ");
		printf("Contents of reg %d  is %X\n",reg,i);
		printf("errno=%d\n",i);
		return -1;
	}
	printf("Contents of reg %d  is %X\n",reg,i);
}
int pread(pid_t pid,int *addr, int *buf,int siz)
{
	int i;
	if ((i=ptrace(PT_READ_BLOCK, pid, addr, siz, buf)) != siz)
	{
		perror("unable to read inst at abc ");
		printf("errno=%d\n",i);
		return -1;
	}
	return 0;
}

int pwrite(pid_t pid,int *addr, int *buf,int siz)
{
	int i;

	if ((i=ptrace(PT_WRITE_BLOCK, pid, addr, siz, buf)) != siz)
	{
		perror("unable to write inst at abc \n");
		printf("%d i=%d\n",errno,i);
		return -1;
	}
	return 0;
}

int pdetach(pid_t pid)
{
        if(ptrace(PT_DETACH, pid, 0, SIGPWR, 0) == -1)
	{
		perror("Detach didn't happen\n");
		return -1;
	}
	printf("Detached\n");
	return 0;
}
