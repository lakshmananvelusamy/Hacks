#include<stdio.h>


myfunc()
{
	printf("I fixed it dynamically...\n");
	fflush(stdout);
}
