#include <stdio.h>
#include <sys/reg.h>
#include <sys/ptrace.h>
#include <sys/ldr.h>
#include <sys/wait.h>
#include<sys/errno.h>
#include<sys/signal.h>
#include<sys/reg.h>
#include "patch.h"

unsigned int dlopentoc=0xF06656B8;
unsigned int dlsymtoc=0xF06656C4;


int hotpatch(pid_t pid,int *oldfp, char *shrobj, char *funcname)
{
	unsigned int rbuf[256],wbuf[256],siz=0;
	int p1,p2,len;
	p1=len=loadprolog(wbuf);siz+=len;
	len=loadr3(&wbuf[siz/4],NULL);siz+=len;
	wbuf[siz/4]=0x38800002; siz+=4; /* li r4,02 */
	len=loadcall(&wbuf[siz/4],dlopentoc,0);siz+=len;
	p2=siz;
	len=loadr4(&wbuf[siz/4],NULL);siz+=len;
        len=loadcall(&wbuf[siz/4],dlsymtoc,0);siz+=len;
wbuf[siz/4]=0x80030000;siz+=4; /*       lwz   r0,0x0(r3) */
wbuf[siz/4]=0x80430004;siz+=4; /*       lwz   r2,0x4(r3)*/
wbuf[siz/4]=0x7c0903a6;siz+=4; /*       mtctr   r0                          */
wbuf[siz/4]=0x4e800421;siz+=4; /*       bctrl                               */
wbuf[siz/4]=0x60000000;siz+=4; /*       ori   r0,r0,0x0                     */
wbuf[siz/4]=0x80410014;siz+=4; /*       lwz   r2,0x14(r1)                   */

	
	len=loadepilog(&wbuf[siz/4]);siz+=len;

	strcpy(&wbuf[siz/4],shrobj);
	loadr3(&wbuf[p1/4],( ((unsigned int)oldfp) + siz));
	siz+=strlen(shrobj)+1;
	loadr4(&wbuf[p2/4],( ((unsigned int)oldfp) + siz));
	strcpy(&wbuf[siz/4],funcname);
	siz+=strlen(funcname)+1;

	pattach(pid);
	pread(pid,oldfp,rbuf,siz);
	if(pwrite(pid,oldfp,wbuf,siz)==0)
		printf("Patched\n");
/*	pcontinue(pid);
	preadreg(pid,GPR3);
	preadreg(pid,GPR4);
	preadreg(pid,IAR);*/
	
	pdetach(pid);
}

int main(int argc,char *argv[])
{
	pid_t pid;
	unsigned int oldfp;

	sscanf(argv[1],"%d",&pid);
	sscanf(argv[2],"0x%X",&oldfp);

        printf("pid=%d oldfp=%X obj=%s func=%s\n",pid,oldfp,argv[3],argv[4]);

	hotpatch(pid,oldfp,argv[3],argv[4]);

        return 0;
}
