#include<stdio.h>


abc()
{
	printf("Hello\n");
}


main()
{
	abc();
}

