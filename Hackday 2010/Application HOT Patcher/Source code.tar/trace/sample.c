#include<stdio.h>

abc()
{
	int i;
	printf("\nInside abc\n");
	i=0;
	i++;
	i++;
	i++;
	i++;
	i++;
}
abc1()
{
	int i;
	printf("Inside abc1111111\n");
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
	i++;
}

abc2()
{
	printf("Inside abc222222\n");
}


abc3()
{
	printf("Inside inside abc3 lax..............\n");
}
main()
{
	int i=0;
	while(1)
	{
		abc();
		sleep(3);
	}
}
