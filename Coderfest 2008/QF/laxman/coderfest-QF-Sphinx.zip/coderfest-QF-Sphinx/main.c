#include<stdio.h>
#include<string.h>
FILE *p1, *p2, *p3, *p5, *p6;
char s1[1024], s2[1024],s[1024], ss[1024];
int a,b,a1,b1,ca,da;

/* Calculates the ascii sum of a string */

int strascii(char *s)
{
	int i=0;
	while( *s)
	{
		i+=*s;
		s++;
	}
	return i;
}

/* This function determines whether the scrambled word can be decoded by splitting it; returns 1 on success*/

int find_split(char *s , char *s1, char *ss)
{
	int i=0,j=0,flag;
        int ch1[26]={0},ch2[26]={0};
	char t[1024];
	for(i=0;i<strlen(s);i++)
        {
                ch1[s[i]-97]++;
                ch2[s1[i]-97]++;
        }
        for(i=0;i<26;i++)
                if(ch1[i] != ch2[i])
                        return 0;
	if ( strlen(s1)>=2 )
	{
		for(i=0;i<strlen(s1)-1;i++)
		{
			t[0] = s1[i];
			t[1] = s1[i+1];
			t[2] = '\0';
			if(strstr(s,t)) flag = 1 ; 
		}
		if ( flag != 1 ) return 0;
	} 
	fprintf(p6,"%s %s %s\n", ss, s, s1);
       	printf("%s %s\n", ss , s1);
  	return 1; 	
}

/* This function determines whether the scrambled word can be decoded using the split given in the decoder file; returns 1 on success */

int find_pat(char *s,char *s1,char *s2)
{
	char t[1024];
	int i=0,j=0;
	int ch1[26]={0},ch2[26]={0};
	for(j=0;j<strlen(s2);j++)
	{
		if(s2[j]=='-'||s2[j+1]==0)
		{
			if (s2[j+1] ==0 )  { t[i++] = s2[j]; }
			t[i]='\0';
			if(strstr(s,t)==NULL)
				return 0;
			i=0;
		}
		else
			t[i++]=s2[j];
	}
	for(i=0;i<strlen(s);i++)
	{
		if ( s[i] >=97 && s[i] <= 97) ch1[s[i]-97]++;
		if ( s[i] >=65 && s[i] <=90 ) ch1[s[i]-65]++;
		if ( s1[i] >=97 && s1[i] <= 97) ch2[s1[i]-97]++;
                if ( s1[i] >=65 && s1[i] <=90 ) ch2[s1[i]-65]++;
	}
	for(i=0;i<26;i++)
		if(ch1[i] != ch2[i])
			return 0;
	return 1;
}
/* Main Program */

int main()
{
	char t;
	long fp1, fp2, fp3;
	p1 = fopen("temp2.txt","r");
	p2 = fopen("temp1.txt","r");
	p5 = fopen("out3.txt","w");
        p6 = fopen("split.txt","w"); 
	fp1=(long)ftell(p2);
	/* This loop goes till the last word of the codedfile.txt */
	while (!feof(p1))
	{
		fscanf(p1,"%s %s %d %d\n",ss,s,&a,&ca);
		fseek(p2,fp1,SEEK_SET);

		/* This loop goes till the last word of the Decoderfile.txt */

		while(!feof(p2))
		{
			fscanf(p2,"%s %s %d %d\n",s1,s2,&b,&da);
                        
			/* The input files are sorted on the basis of length and the ascii sum.
                         * So word checking is done for only like length decoder and coded words. 
			 */ 
			
                        /* If the length of word in decoder file is greater than word in codedfile print it as invalid */
			
			if(b>a)
			{
				fprintf(p5,"%s %s\n",ss,s);
                                printf("%s %s\n",ss,s);
				break;
			}
			/* If the length of word in decoder file is smaller than word in codedfile read till correct length word */
			else if(b<a)
			{
				if(!feof(p2))
				{
					do
					{
						fp1=(long)ftell(p2);
						fscanf(p2,"%s %s %d %d\n",s1,s2,&b,&da);
					}while( b < a && !feof(p2));
				}
				if(feof(p2)&&b!=a)
				{
					if(!feof(p1))
					{
						do
						{
							fprintf(p5,"%s %s\n",ss,s);
							printf("%s %s\n",ss,s);
							fscanf(p1,"%s %s %d %d\n",ss,s,&a,&da);
						}while(!feof(p1));
					}
					fprintf(p5,"%s %s\n",ss,s);
										printf("%s %s\n",ss,s);
					fclose(p1);
					fclose(p2);
					fclose(p5);
					fclose(p6);
					return(0);
				}
			}
			/* If lengths are equal */	
			if( a==b )
			{
				/* If the ascii sum of word in decoder file is greater than word in codedfile print it as invalid */	
				if(da > ca )
				{
					  fprintf(p5,"%s %s\n",ss,s);
					  printf("%s %s\n",ss,s);
					  break;
				}
				/* If the ascii sum of word in decoder file is smaller than word in codedfile read till correct length word */
				else if( da < ca)
				{
					if(!feof(p2))
					{
						do
						{
							fp1=(long)ftell(p2);
							fscanf(p2,"%s %s %d %d\n",s1,s2,&b,&da);
						}while ( da < ca && b==a && !feof(p2));
					}
					if(feof(p2)&&da!=ca)
					{
						if(!feof(p1))
						{
							do
							{
                                                        	fprintf(p5,"%s %s\n",ss,s);
                                                        	printf("%s %s\n",ss,s);
                                                        	fscanf(p1,"%s %s %d %d\n",ss,s,&a,&da);
                                                	}while(!feof(p1));
                                        }
                                        fprintf(p5,"%s %s\n",ss,s);
                                        printf("%s %s\n",ss,s);
                                        fclose(p1);
                                        fclose(p2);
                                        fclose(p5);
                                        fclose(p6);
                                        return(0);
                                	}
				}
				/* If ascii sum are equal */
				if ( da == ca && b==a )
				{
					if(*s2 != '?')
					{
						if(find_pat(s,s1,s2))
						{
							printf("%s %s\n",ss,s1);
							break;
						}
					}
					else 
					{ 
						if(find_split(s,s1,ss))
						{
							break;
						}	
					}
				} 
			}
			if(feof(p2))
			{
				fprintf(p5,"%s %s\n",ss,s);
                                printf("%s %s\n",ss,s); 
				break;
			}
		}
	}
	fclose(p1);
	fclose(p2);
	fclose(p5);
        fclose(p6);
	return 0;
}
