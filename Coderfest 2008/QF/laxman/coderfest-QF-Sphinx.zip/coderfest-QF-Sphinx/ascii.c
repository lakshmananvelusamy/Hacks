#include<stdio.h>

/* This function calculates the ascii sum of a string passed and returns it */
 
int strascii(char *s)
{
        int i=0;
        while( *s)
        {
                i+=*s;
                s++;
        }
        return i;
}

/* reads from the sorted input files and calcutes the ascii sum from above function and writes it to different file */

int main()
{
 	FILE *fp,*fp1,*fp2,*fp3;
	int count;
	char first[1024],second[1024],third[1024],fourth[1024];
	fp = fopen("temp2ascii.txt","r");
	fp1 = fopen("temp2unsorted.txt","w");
        while(!feof(fp))
	{
		fscanf(fp,"%s %s %s\n",first,second,third);
		count=strascii(second);
		fprintf(fp1,"%s %s %s %d \n",first,second,third,count);
	}
	fclose(fp);
	fclose(fp1);
	fp2 = fopen("temp1ascii.txt","r");
        fp3 = fopen("temp1unsorted.txt","w");
        while(!feof(fp2))
        {
                fscanf(fp2,"%s %s %s\n",first,second,third);
                count=strascii(first);
                fprintf(fp3,"%s %s %s %d \n",first,second,third,count);
        }
	fclose(fp2);
        fclose(fp3);
}
