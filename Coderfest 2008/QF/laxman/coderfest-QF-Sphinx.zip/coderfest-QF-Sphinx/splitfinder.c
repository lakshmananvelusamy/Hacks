#include<stdio.h>
#include<string.h>
#include<stdlib.h>
FILE * fp1, * fp2;
/* Main Program */

/* The Main.c writes all scrambled words that can be decoded if split is found to split.txt */
/* This program reads the split.txt file and tries to find out a split, such that all scrambled versions of a single word can be made in to valid words */

int main()
{
        char ss[1024],s[1024],s1[1024],tm[1024];
        char **t,*ai,b[1024];
	int count=0,i,a1,a2,j,k,n1,fl;
	long fp;
        fp1=fopen("temp3.txt","r");
        while(!feof(fp1))
        {
                int flag[1024]={0},tt=0;
                fp = ftell(fp1);
                count=0;
                fscanf(fp1,"%s %s %s",ss,s,tm);
                if(!feof(fp1))
                {
                        do
                        {
                                fscanf(fp1,"%s %s %s",ss,s,s1);
                                count++;
                        }while((!strcmp(s1,tm)) && !feof(fp1));
						if(feof(fp1))
							count++;
						fseek(fp1,fp,SEEK_SET);
				}
				else
				{
						strcpy(s1,tm);
						count=1;
				}
				t=(char **)malloc(count*sizeof(char *));
				for(i=0; i < count; i++)
				{
						t[i] = (char *)malloc(strlen(tm)+1);
						fscanf(fp1,"%s %s %s",ss,s,s1);
						strcpy(t[i],s);
						t[i][strlen(s)]='\0';
				}
				for(i=strlen(s1);i>0;i--)
				{
						for(j=0;j+i<=strlen(s1);j++)
						{
								fl=0;
								for(a1=j,a2=0;a2<i;a1++,a2++)
								{
										if(flag[a1])
										{
												while(flag[a1])
												{
														j++;
														a1++;
												}
												fl=1;
												j--;
												break;
										}
										b[a2]=s1[a1];
								}
								if(fl)
								continue;
								b[a2]='\0';
								for(k=0;k<count;k++)
								{
										if(strstr(t[k],b)==NULL)
										{
												 break;
                                        }
                                }
                                if(k==count)
                                {
                                        tt++;
                                        for(n1=j;n1<i+j;n1++)
                                                flag[n1]=tt;
                                }
                        }
                }
		printf("%s ",s1);
                for(i=0;i<strlen(s1);)
                {
                        int w = flag[i];
                        do
                        {
                                printf("%c",s1[i]);i++;
                        }while(w == flag[i]);
			if(i!=strlen(s1))printf("-");
                }
		printf("\n");
		for(i=0;i<count;i++)
			free(t[i]);
		free(t); 

        }
	fclose(fp1);
}

